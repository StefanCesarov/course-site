<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;

class UserController extends Controller
{
    //

    public function index()
    {
        return view('users.index')->with('users', User::paginate(50)->sortBy('email', 1));
    }

    public function edit ()

    {
        return redirect()->back();
    }

    public function grantAccess (User $user)
    {
        
        $user->update(
            ['role' => '2']
        );

        return redirect()->back();
    }    

    public function denyAccess (User $user)
    {
        
        $user->update(
            ['role' => '1']
        );

        return redirect()->back();
    }    
}
