<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Course;
use App\Models\Language;
use App\Models\Framework;
use App\Models\Category;

class CourseController extends Controller
{
    //
        
    public function index()
    {
      //dd(Course::all());
      return view('front.index')
      ->with('courses', Course::paginate(18))
      ->with('languages', Language::all())
      ->with('frameworks', Framework::all());
    }

    // show single COURSE on the webpage
    public function show(Course $course)
    {
        return view('front.single-course')
          ->with('course', $course)
          ->with('languages', Language::all())
          ->with('frameworks', Framework::all());
    }

    public function language (Language $language)
    {
        return view('front.language')
        ->with('getLanguage', $language)
        ->with('courses', Course::where('language_id', $language->id)->paginate(6))
        ->with('languages', Language::all())
        ->with('frameworks', Framework::all());
    }

    public function framework (Framework $framework)
    {
     
        return view('front.framework')
        ->with('getFramework', $framework)
        ->with('languages', Language::all())
        ->with('frameworks', Framework::all())
        ->with('courses', Course::where('framework_id', $framework->id)->paginate(6));
        
    }

}
