@extends('layouts.app-course')
@section('content')

<section id="mu-course-content">
    <div class="container">
    <div class="mu-title">
      <h2 class='cust-content-title'>{{ $getFramework->name}} kursevi</h2>
    </div>
    <div class="row">
       <div class="col-md-12">
         <div class="mu-course-content-area">
            <div class="row">
              <div class="col-md-9">
                <!-- start course content container -->
                <div class="mu-course-container mu-blog-archive">
                  <div class="row">
                @foreach($courses as $course)
                @if($loop->iteration % 2 == 0)
                <div class="row">
                @endif
                <div class="col-md-6 col-sm-6"> 
                  <article class="mu-blog-single-item">
                    <figure class="mu-blog-single-img">
                      <a href="{{ route('single-course-show', $course->id) }}" target="_blank"><img src="{{ asset('/storage/Course/'.$course->putanja_slike) }}" alt="img"></a>
                      <figcaption class="mu-blog-caption">
                        <h3><a href="{{ route('single-course-show', $course->id) }}">{{ $course->naziv }}</a></h3>
                      </figcaption>                      
                    </figure>
                    <div class="mu-blog-meta">
                    <a >Kreiran:</a>
                      <a >{{ $course->kreirano_dana }}</a>
                          <button class="mu-language-btn" >{{ $course->language['name'] }}</button>
                    </div>
                    <div class="mu-blog-description">
                      <p>{{ $course->opis_naziva }}</p>
                      <a class="mu-read-more-btn" href="{{ route('single-course-show', $course->id) }}" target="_blank">Saznaj više</a>
                      @auth
                        @if(auth()->user()->haveAcces())
                        <a href="{{ $course->torrent_fajl }}" target="_blank"><button class="mu-download-btn">Preuzmi</button></a>
                        @else
                          <a href="{{ route('preuzimanje-placanje') }}" ><button class="mu-lock-btn">Otključaj kurs</button></a>
                        @endif
                      @else
                          <a href="{{ route('preuzimanje-placanje') }}" ><button class="mu-lock-btn">Otključaj kurs</button></a>
                      @endauth
                    </div>
                  </article>
                </div>
                @if($loop->iteration % 2 == 0)
                </div>
                @endif
                @endforeach
                  </div>
                </div>

                {{ $courses->links() }}
                <!-- end course content container -->
              </div>
              @include('partials.sidebar-learn')
           </div>
         </div>
       </div>
     </div>
   </div>
 </section>

@endsection