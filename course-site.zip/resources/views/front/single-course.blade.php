@extends('layouts.app-course')
@section('content')

 <!-- Page breadcrumb -->
 <section id="mu-page-breadcrumb">
   <div class="container">
     <div class="row">
       <div class="col-md-12">
         <div class="mu-page-breadcrumb-area">
           <h2>Detalji kursa</h2>
           <ol class="breadcrumb">
            <li><h2>{{ $course->naziv }}</h2></li>  
            <li class="active">Napomena: Opis kursa je preuzet sa Udemy sajta.</li>          
          </ol>
         </div>
       </div>
     </div>
   </div>
 </section>
 <!-- End breadcrumb -->
 <section id="mu-course-content">
   <div class="container">
     <div class="row">
       <div class="col-md-12">
         <div class="mu-course-content-area">
            <div class="row">
              <div class="col-md-9">
                <!-- start course content container -->
                <div class="mu-course-container mu-course-details">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="mu-latest-course-single">
                        <figure class="mu-latest-course-img">
                          <a href="#"><img src="{{ asset('/storage/Course/'.$course->putanja_slike) }}" alt="img"></a>
                        </figure>
                        <div class="mu-latest-course-single-content">
                          <h3>{{ $course->opis_naziva }}</h3>
                          @auth
                        @if(auth()->user()->haveAcces())
                        <a href="{{ $course->torrent_fajl }}" target="_blank"><button class="mu-download-btn">Preuzmi</button></a>
                        @else
                          <a href="{{ route('preuzimanje-placanje') }}" ><button class="mu-lock-btn">Otključaj kurs</button></a>
                        @endif
                      @else
                          <a href="{{ route('preuzimanje-placanje') }}" ><button class="mu-lock-btn">Otključaj kurs</button></a>
                      @endauth
                          <h4>Osnovne informacije</h4>
                          <ul>
                            <li> <span>Jezik:</span> <span>{{ $course->language['name']}}</span></li>
                            <li> <span>Kreiran dana:</span> <span>{{ $course->kreirano_dana}}</span></li>
                            <li> <span>Veličina materijala:</span> <span>{{ $course->velicina_materijala }}</span></li>
                            <li> <span>Kreator kursa:</span> <span>{{ $course->kreirano_od}}</span></li>
                            <li> <span>Jezik kursa:</span> <span>{{ $course->jezik}}</span></li>
                            <li> <span>Polazno znanje:</span> <span>{{ $course->polazno_znanje}}</span></li>
                            <li> <span>Kome je namenjen:</span> <span style="font-size:13px">{{ $course->namenjen}}</span></li>
                            <li> <span>Udemy link (opis):</span> <span style="font-size:13px">{{ $course->udemy_link}}</a></span></li>
                          </ul>
                          <h4>Šta ćete naučiti?</h4>
                          <p>{!! $course->kratak_sadrzaj !!}</p>
                          <h4>Opis kursa</h4>
                          <p>{!! $course->opis !!}</p>
                          
                        </div>
                        @auth
                        @if(auth()->user()->haveAcces())
                        <a href="{{ $course->torrent_fajl }}" target="_blank" style="margin-left: 15px;"><button class="mu-download-btn">Preuzmi</button></a>
                        @else
                          <a href="{{ route('preuzimanje-placanje') }}" style="margin-left: 15px;" ><button class="mu-lock-btn">Otključaj kurs</button></a>
                        @endif
                      @else
                          <a href="{{ route('preuzimanje-placanje') }}" style="margin-left: 15px;"><button class="mu-lock-btn">Otključaj kurs</button></a>
                      @endauth
                      </div> 
                    </div>                                   
                  </div>
                </div>
                <!-- end course content container -->
              </div>
              @include('partials.sidebar-learn')
           </div>
         </div>
       </div>
     </div>
   </div>
 </section>

@endsection