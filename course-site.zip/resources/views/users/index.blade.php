@extends('layouts.app')

@section('content')
<div class="container">
    <br>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Korisnici</div>

                <div class="card-body">
                    @if($users->count()>0)
                    <table class="table">
                        <thead>
                            <th>R.N.</th>
                            <th>Email</th>
                            <th>Role</th>
                            <td>Dodeli pravo</td>
                        
                        </thead>
                        <tbody>
                        @foreach($users as $user)
                        
                        <tr>
                            <td>{{ $loop->iteration }}.</td>
                            <td>{{ $user->email }}</td>
                            <td>{{ $user->role }}</td>
                            
                            @if(!$user->isadmin())
                            <td> 
                                <form action="{{ route('users-access', $user->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn btn-info btn-sm" style="color:#FFFFFF">Otkljucaj korisnika</a>
                                </form>
                            </td>
                            <td>
                            <form action="{{ route('users-deny-access', $user->id) }}" method="POST">
                                    @csrf
                                    <button type="submit" class="btn btn-danger btn-sm" style="color:#FFFFFF">Ukini dozvolu</a>
                                </form>
                            </td>
                            @endif
                        </tr>
                        @endforeach
                        </tbody>
                    </table>
                    @else
                    <div class="text-center">
                        <h3 class="text-center">Nema registrovanih korisnika!</h3>
                    </div>
                    @endif
                </div>
            </div>

       

        </div>
</div>
@endsection
