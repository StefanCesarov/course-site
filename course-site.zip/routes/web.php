<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'App\Http\Controllers\CourseController@index')->name('kurs.index');
Route::get('/course/{course}', 'App\Http\Controllers\CourseController@show')->name('single-course-show');
Route::get('/backend', 'App\Http\Controllers\CategoryController@backendCourses')->name('backend-courses');
Route::get('/fullstack', 'App\Http\Controllers\CategoryController@fullstackCourses')->name('fullstack-courses');
Route::get('/frontend', 'App\Http\Controllers\CategoryController@frontendCourses')->name('frontend-courses');
Route::get('/preuzimanje-placanje', 'App\Http\Controllers\SiteController@preuzimanjePlacanje')->name('preuzimanje-placanje');

Route::get('course/language/{language}', 'App\Http\Controllers\CourseController@language')->name('course-language');
Route::get('course/framework/{framework}', 'App\Http\Controllers\CourseController@framework')->name('course-framework');

Auth::routes();
Route::middleware(['auth', 'admin'])->group( function (){

    Route::get('/users', 'App\Http\Controllers\UserController@index')->name('users-index');
  
    Route::post('users/user-list/grant-access/{user}', 'App\Http\Controllers\UserController@grantAccess')->name('users-access');
    Route::post('users/user-list/deny-access/{user}', 'App\Http\Controllers\UserController@denyAccess')->name('users-deny-access');
    Route::get('/users_edit_profile', [ 'as' => 'users_edit_profile', 'uses' => 'App\Http\Controllers\UserController@edit']);
    Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
});





