

<?php $__env->startSection('content'); ?>
<div class="container">
    <br>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Korisnici</div>

                <div class="card-body">
                    <?php if($users->count()>0): ?>
                    <table class="table">
                        <thead>
                            <th>R.N.</th>
                            <th>Email</th>
                            <th>Role</th>
                            <td>Dodeli pravo</td>
                        
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <tr>
                            <td><?php echo e($loop->iteration); ?>.</td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->role); ?></td>
                            
                            <?php if(!$user->isadmin()): ?>
                            <td> 
                                <form action="<?php echo e(route('users-access', $user->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-info btn-sm" style="color:#FFFFFF">Otkljucaj korisnika</a>
                                </form>
                            </td>
                            <td>
                            <form action="<?php echo e(route('users-deny-access', $user->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" style="color:#FFFFFF">Ukini dozvolu</a>
                                </form>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="text-center">
                        <h3 class="text-center">Nema registrovanih korisnika!</h3>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

       

        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Stefan\Favorites\Posao\laravel\course-site\resources\views/users/index.blade.php ENDPATH**/ ?>