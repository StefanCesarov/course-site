<?php if($paginator->hasPages()): ?>
<div class="mu-pagination">
    <nav role="navigation" aria-label="<?php echo e(__('Pagination Navigation')); ?>">
        <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">    
        <ul class="pagination">
            <?php if($paginator->onFirstPage()): ?>
            <li>
                <a aria-label="Previous" >
                <span class="fa fa-angle-left"></span>Prev
                </a>
            </li>
            <?php else: ?>
            <li>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" aria-label="Previous">
                     <span class="fa fa-angle-left"></span>Prev
                </a>
            </li>
            <?php endif; ?>

            <?php if($paginator->hasMorePages()): ?>
            <li>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" aria-label="Next">
                    Next<span class="fa fa-angle-right"></span>
                </a>
            </li>
            <?php else: ?>
            <li>
                <a aria-label="Next">
                    Next<span class="fa fa-angle-right"></span>
                </a>
            </li>
            <?php endif; ?>
        </ul>
        </div>
            <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                <p class="text-sm text-gray-700 leading-5">
                    <?php echo __('Showing'); ?>

                    <span class="font-medium"><?php echo e($paginator->firstItem()); ?></span>
                    <?php echo __('to'); ?>

                    <span class="font-medium"><?php echo e($paginator->lastItem()); ?></span>
                    <?php echo __('of'); ?>

                    <span class="font-medium"><?php echo e($paginator->total()); ?></span>
                    <?php echo __('results'); ?>

                </p>
            </div>

            <ul class="pagination">
                    
                    <?php if($paginator->onFirstPage()): ?>
                    <li >
                         <a aria-label="Previous" >
                            <span class="fa fa-angle-left"></span>Prev
                        </a>
                      </li>
                    <?php else: ?>
                    <li>
                        <a href="<?php echo e($paginator->previousPageUrl()); ?>" aria-label="Previous">
                            <span class="fa fa-angle-left"></span>Prev
                        </a>
                    </li>
                    <?php endif; ?>

                    
                    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if(is_string($element)): ?>
                            <li>
                                <a><?php echo e($element); ?></a>
                            </li>
                        <?php endif; ?>

                        
                        <?php if(is_array($element)): ?>
                            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($page == $paginator->currentPage()): ?>
                                    <li class="active">
                                        <a ><?php echo e($page); ?></a>
                                    </li>
                                <?php else: ?>
                                <li>
                                    <a href="<?php echo e($url); ?>" aria-label="<?php echo e(__('Go to page :page', ['page' => $page])); ?>">
                                        <?php echo e($page); ?>

                                    </a>
                                </li>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php if($paginator->hasMorePages()): ?>
                    <li>
                        <a href="<?php echo e($paginator->nextPageUrl()); ?>" aria-label="Next">
                            Next<span class="fa fa-angle-right"></span>
                        </a>
                    </li>
                    <?php else: ?>
                    <li >
                    <a aria-label="Next">
                        Next<span class="fa fa-angle-right"></span>
                    </a>
                </li>
                    <?php endif; ?>
            </ul>
    </nav>
</div>
<?php endif; ?>
<?php /**PATH C:\Users\Stefan\Favorites\Posao\laravel\course-site\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>