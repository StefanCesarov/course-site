<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    
    <title>SCE Kursevi programiranja</title>
    <meta name="description" content="Video kursevi programiranja! Postani programerer, lako i jednostavno.">

        <!--   open graph -->
    <meta property="og:title" content="SCE Kursevi programiranja">
    <meta property="og:description" content="Mesto gde se postaje programer. Online kursevi programiranja. Savladaj potrebne vestine uz nase video tutorijale.">


    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('img/favIconSCE.png')); ?>" type="image/x-icon">

    <!-- Font awesome -->
    <link href="<?php echo e(asset('css/font-awesome.css')); ?>" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">   
    <!-- Slick slider -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/slick.css')); ?>">          
    <!-- Fancybox slider -->
    <link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.css')); ?>" type="text/css" media="screen" /> 
    <!-- Theme color -->
    <link id="switcher" href="<?php echo e(asset('css/theme-color/default-theme.css')); ?>" rel="stylesheet">          

    <!-- Main style sheet -->
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">    

   
    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,400italic,300,300italic,500,700' rel='stylesheet' type='text/css'>
    

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  </head>
  <body> 

  <!--START SCROLL TOP BUTTON -->
    <a class="scrollToTop" href="#">
      <i class="fa fa-angle-up"></i>      
    </a>
  <!-- END SCROLL TOP BUTTON -->

  <!-- Start header  -->
  <header id="mu-header">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="mu-header-area">
            <div class="row">
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="mu-header-top-left">
                  <div class="mu-top-email">
                    <i class="fa fa-envelope"></i>
                    <span>sce.kursevi@gmail.com</span>
                  </div>
                  <div class="mu-top-phone">
                    <i class="fa fa-phone"></i>
                    <span>064-349-31-36</span>
                  </div>
                </div>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
                <div class="mu-header-top-right">
                  <nav>
                  <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->isAdmin()): ?>
                      <a href="<?php echo e(route('users-index')); ?>">Korisnici</a>
                    <?php endif; ?>
                  <?php endif; ?>
                   <ul class="mu-top-social-nav">

                  <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li>
                                    <a href="<?php echo e(route('login')); ?>">
                                    <button><i class="fa fa-user"></i> <?php echo e(__(' Uloguj se')); ?></button></a>
                                </li>
                            <?php endif; ?>
                            
                            <?php if(Route::has('register')): ?>
                                <li>
                                    <a href="<?php echo e(route('register')); ?>"><?php echo e(__('Registruj se')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                                <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                            document.getElementById('logout-form').submit();">
                                                <button><i class="fa fa-user"></i><?php echo e(__(' Izloguj se')); ?></button>
                                            </a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                    </a>
                                </li>
                  <?php endif; ?>
                  <!--   <ul class="mu-top-social-nav">

                      <li><a href="#"><span class="fa fa-facebook"></span></a></li>
                      <li><a href="#"><span class="fa fa-twitter"></span></a></li>
                      <li><a href="#"><span class="fa fa-google-plus"></span></a></li>
                      <li><a href="#"><span class="fa fa-linkedin"></span></a></li>
                      <li><a href="#"><span class="fa fa-youtube"></span></a></li>
                    -->
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- End header  -->
  <!-- Start menu -->
  <section id="mu-menu">
    <nav class="navbar navbar-default" role="navigation">  
      <div class="container">
        <div class="navbar-header">
          <!-- FOR MOBILE VIEW COLLAPSED BUTTON -->
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <!-- LOGO -->              
          <!-- TEXT BASED LOGO -->
          <a class="navbar-brand" href="<?php echo e(route('kurs.index')); ?>"><i class="fa fa"><b style="font-family: 'Impact';font-style: italic;text-decoration: underline;">SCE</b></i><span> KURSEVI</span></a>
          <!-- IMG BASED LOGO  -->
          <!-- <a class="navbar-brand" href="index.html"><img src="assets/img/logo.png" alt="logo"></a> -->
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul id="top-menu" class="nav navbar-nav navbar-right main-nav">
            <li class="<?php echo e(request()->is('/') ? 'active' : ''); ?>"><a href="<?php echo e(route('kurs.index')); ?>">Početna</a></li>
            <li class="<?php echo e(request()->is('backend') ? 'active' : ''); ?>"><a href="<?php echo e(route('backend-courses')); ?>">Backend</a></li>
            <li class="<?php echo e(request()->is('frontend') ? 'active' : ''); ?>"><a href="<?php echo e(route('frontend-courses')); ?>">Front-End</a></li>
            <li class="<?php echo e(request()->is('fullstack') ? 'active' : ''); ?>"><a href="<?php echo e(route('fullstack-courses')); ?>">Fullstack</a></li>                     
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Jezik <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu" role="menu">
                  <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('course-language', $language->id)); ?>"><?php echo e($language->name); ?></a></li>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
              </ul>
            </li>           
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown">Framework <span class="fa fa-angle-down"></span></a>
              <ul class="dropdown-menu" role="menu">
              <?php $__currentLoopData = $frameworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $framework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(route('course-framework', $framework->id)); ?>"><?php echo e($framework->name); ?></a></li>  
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
              </ul>
            </li>            
            <li class="<?php echo e(request()->is('preuzimanje-placanje') ? 'active' : ''); ?>"><a href="<?php echo e(route('preuzimanje-placanje')); ?>">Korisno</a></li>
          </ul>                     
        </div><!--/.nav-collapse -->        
      </div>     
    </nav>
  </section>
  <!-- End menu -->

  <?php echo $__env->yieldContent('content'); ?>
  <!-- Start footer -->
  <footer id="mu-footer">
    <!-- start footer top -->
    <div class="mu-footer-top">
      <div class="container">
        <div class="mu-footer-top-area">
          <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
              <h4>Informacije</h4>
                <ul>
                  <li><a href="<?php echo e(route('preuzimanje-placanje')); ?>">Kako otljučati kurseve</a></li>
                  <li><a href="<?php echo e(route('preuzimanje-placanje')); ?>">Uputstvo za preuzimanje kurseva</a></li>
                  <li><a href="/">Kursevi</a></li>
                </ul>
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
                <h4>Kontakt</h4>
                <address>
                  <p>Telefon: 064-349-31-36</p>
                  <p>Internet sajt: sce-kursevi.com</p>
                  <p>Email: sce.kursevi@gmail.com</p>
                </address>
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
              <h4>Korisni sajtovi</h4>
                <ul>
                  <li><a href="https://stackoverflow.com/" target="_blanck">stackoverflow.com</a></li>
                  <li><a href="https://www.w3schools.com/" target="_blanck">w3schools.com</a></li>
                  <li><a href="https://coddyschool.com/upload/Addison_Wesley_The_Object_Orient.pdf" target="_blanck">Objektno orijentisano programiranje</a></li>
                </ul>
              </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-3">
              <div class="mu-footer-widget">
              <h4>Zaposli se u IT sektoru</h4>
                <ul>
                  <li><a href="https://www.helloworld.rs/" target="_blanck">helloworld.rs</a></li>
                  <li><a href="https://www.joberty.rs/" target="_blanck">joberty.rs</a></li>
                  <li><a href="https://startit.rs/" target="_blanck">startit.rs</a></li>
                </ul>
              </div>
            </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- end footer top -->
    <!-- start footer bottom -->
    <div class="mu-footer-bottom">
      <div class="container">
        <div class="mu-footer-bottom-area">
          <p>&copy; All Right Reserved. Designed by <a>SCE</a></p>
        </div>
      </div>
    </div>
    <!-- end footer bottom -->
  </footer>
  <!-- End footer -->
  
  <!-- jQuery library -->
  <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>  
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>   
  <!-- Slick slider -->
  <script type="text/javascript" src="<?php echo e(asset('js/slick.js')); ?>"></script>
  <!-- Counter -->
  <script type="text/javascript" src="<?php echo e(asset('js/waypoints.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('js/jquery.counterup.js')); ?>"></script>  
  <!-- Mixit slider -->
  <script type="text/javascript" src="<?php echo e(asset('js/jquery.mixitup.js')); ?>"></script>
  <!-- Add fancyBox -->        
  <script type="text/javascript" src="<?php echo e(asset('js/jquery.fancybox.pack.js')); ?>"></script>
  
  
  <!-- Custom js -->
  <script src="<?php echo e(asset('js/custom.js')); ?>"></script> 

  </body>
</html><?php /**PATH C:\Users\Stefan\Favorites\Posao\laravel\course-site\resources\views/layouts/app-course.blade.php ENDPATH**/ ?>