<div class="col-md-3">
                <!-- start sidebar -->
                <aside class="mu-sidebar">
                  <!-- start single sidebar -->
                  <div class="mu-single-sidebar">
                    <h3>Nauči jezik</h3>
                    <ul class="mu-sidebar-catg  mu-sidebar-archives">
                    <?php $__currentLoopData = $languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><a href="<?php echo e(route('course-language', $language->id)); ?>"><?php echo e($language->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </div>
                  <!-- end single sidebar -->
                 
                  <!-- start single sidebar -->
                  <div class="mu-single-sidebar">
                    <h3>Nauči framework</h3>
                    <ul class="mu-sidebar-catg mu-sidebar-archives">
                      <?php $__currentLoopData = $frameworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $framework): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                      <li><a href="<?php echo e(route('course-framework', $framework->id)); ?>"><?php echo e($framework->name); ?></a></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </div>
                  <!-- end single sidebar -->
                  <!-- start single sidebar -->

                  <!-- end single sidebar -->
                </aside>
                <!-- / end sidebar -->
</div><?php /**PATH C:\Users\Stefan\Favorites\Posao\laravel\course-site\resources\views/partials/sidebar-learn.blade.php ENDPATH**/ ?>