
<?php $__env->startSection('content'); ?>

<section id="mu-course-content">
    <div class="container">
    <div class="mu-title">
      <h2 class='cust-content-title'><?php echo e($getFramework->name); ?> kursevi</h2>
    </div>
    <div class="row">
       <div class="col-md-12">
         <div class="mu-course-content-area">
            <div class="row">
              <div class="col-md-9">
                <!-- start course content container -->
                <div class="mu-course-container mu-blog-archive">
                  <div class="row">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->iteration % 2 == 0): ?>
                <div class="row">
                <?php endif; ?>
                <div class="col-md-6 col-sm-6"> 
                  <article class="mu-blog-single-item">
                    <figure class="mu-blog-single-img">
                      <a href="<?php echo e(route('single-course-show', $course->id)); ?>" target="_blank"><img src="<?php echo e(asset('/storage/Course/'.$course->putanja_slike)); ?>" alt="img"></a>
                      <figcaption class="mu-blog-caption">
                        <h3><a href="<?php echo e(route('single-course-show', $course->id)); ?>"><?php echo e($course->naziv); ?></a></h3>
                      </figcaption>                      
                    </figure>
                    <div class="mu-blog-meta">
                    <a >Kreiran:</a>
                      <a ><?php echo e($course->kreirano_dana); ?></a>
                          <button class="mu-language-btn" ><?php echo e($course->language['name']); ?></button>
                    </div>
                    <div class="mu-blog-description">
                      <p><?php echo e($course->opis_naziva); ?></p>
                      <a class="mu-read-more-btn" href="<?php echo e(route('single-course-show', $course->id)); ?>" target="_blank">Saznaj više</a>
                      <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->haveAcces()): ?>
                        <a href="<?php echo e($course->torrent_fajl); ?>" target="_blank"><button class="mu-download-btn">Preuzmi</button></a>
                        <?php else: ?>
                          <a href="<?php echo e(route('preuzimanje-placanje')); ?>" ><button class="mu-lock-btn">Otključaj kurs</button></a>
                        <?php endif; ?>
                      <?php else: ?>
                          <a href="<?php echo e(route('preuzimanje-placanje')); ?>" ><button class="mu-lock-btn">Otključaj kurs</button></a>
                      <?php endif; ?>
                    </div>
                  </article>
                </div>
                <?php if($loop->iteration % 2 == 0): ?>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>

                <?php echo e($courses->links()); ?>

                <!-- end course content container -->
              </div>
              <?php echo $__env->make('partials.sidebar-learn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           </div>
         </div>
       </div>
     </div>
   </div>
 </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-course', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Stefan\Favorites\Posao\laravel\course-site\resources\views/front/framework.blade.php ENDPATH**/ ?>