
<?php $__env->startSection('content'); ?>

 <!-- Page breadcrumb -->
 <section id="mu-page-breadcrumb">
   <div class="container">
     <div class="row">
       <div class="col-md-12">
         <div class="mu-page-breadcrumb-area">
           <h2>Detalji kursa</h2>
           <ol class="breadcrumb">
            <li><h2><?php echo e($course->naziv); ?></h2></li>  
            <li class="active">Napomena: Opis kursa je preuzet sa Udemy sajta.</li>          
          </ol>
         </div>
       </div>
     </div>
   </div>
 </section>
 <!-- End breadcrumb -->
 <section id="mu-course-content">
   <div class="container">
     <div class="row">
       <div class="col-md-12">
         <div class="mu-course-content-area">
            <div class="row">
              <div class="col-md-9">
                <!-- start course content container -->
                <div class="mu-course-container mu-course-details">
                  <div class="row">
                    <div class="col-md-12">
                      <div class="mu-latest-course-single">
                        <figure class="mu-latest-course-img">
                          <a href="#"><img src="<?php echo e(asset('/storage/Course/'.$course->putanja_slike)); ?>" alt="img"></a>
                        </figure>
                        <div class="mu-latest-course-single-content">
                          <h3><?php echo e($course->opis_naziva); ?></h3>
                          <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->haveAcces()): ?>
                        <a href="<?php echo e($course->torrent_fajl); ?>" target="_blank"><button class="mu-download-btn">Preuzmi</button></a>
                        <?php else: ?>
                          <a href="<?php echo e(route('preuzimanje-placanje')); ?>" ><button class="mu-lock-btn">Otključaj kurs</button></a>
                        <?php endif; ?>
                      <?php else: ?>
                          <a href="<?php echo e(route('preuzimanje-placanje')); ?>" ><button class="mu-lock-btn">Otključaj kurs</button></a>
                      <?php endif; ?>
                          <h4>Osnovne informacije</h4>
                          <ul>
                            <li> <span>Jezik:</span> <span><?php echo e($course->language['name']); ?></span></li>
                            <li> <span>Kreiran dana:</span> <span><?php echo e($course->kreirano_dana); ?></span></li>
                            <li> <span>Veličina materijala:</span> <span><?php echo e($course->velicina_materijala); ?></span></li>
                            <li> <span>Kreator kursa:</span> <span><?php echo e($course->kreirano_od); ?></span></li>
                            <li> <span>Jezik kursa:</span> <span><?php echo e($course->jezik); ?></span></li>
                            <li> <span>Polazno znanje:</span> <span><?php echo e($course->polazno_znanje); ?></span></li>
                            <li> <span>Kome je namenjen:</span> <span style="font-size:13px"><?php echo e($course->namenjen); ?></span></li>
                            <li> <span>Udemy link (opis):</span> <span style="font-size:13px"><?php echo e($course->udemy_link); ?></a></span></li>
                          </ul>
                          <h4>Šta ćete naučiti?</h4>
                          <p><?php echo $course->kratak_sadrzaj; ?></p>
                          <h4>Opis kursa</h4>
                          <p><?php echo $course->opis; ?></p>
                          
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->haveAcces()): ?>
                        <a href="<?php echo e($course->torrent_fajl); ?>" target="_blank" style="margin-left: 15px;"><button class="mu-download-btn">Preuzmi</button></a>
                        <?php else: ?>
                          <a href="<?php echo e(route('preuzimanje-placanje')); ?>" style="margin-left: 15px;" ><button class="mu-lock-btn">Otključaj kurs</button></a>
                        <?php endif; ?>
                      <?php else: ?>
                          <a href="<?php echo e(route('preuzimanje-placanje')); ?>" style="margin-left: 15px;"><button class="mu-lock-btn">Otključaj kurs</button></a>
                      <?php endif; ?>
                      </div> 
                    </div>                                   
                  </div>
                </div>
                <!-- end course content container -->
              </div>
              <?php echo $__env->make('partials.sidebar-learn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           </div>
         </div>
       </div>
     </div>
   </div>
 </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-course', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Stefan\Favorites\Posao\laravel\course-site\resources\views/front/single-course.blade.php ENDPATH**/ ?>